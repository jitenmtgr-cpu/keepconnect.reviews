SIDDHESHWAR FACILITY SERVICES — SECUREX THEME WEBSITE

This website is based on the original Securex HTML/Bootstrap structure. The original CSS/JS libraries and responsive behavior are retained, while the demo CCTV content has been replaced.

MAIN PAGES
- index.html = Home
- about.html = About Us
- service.html = Services
- project.html = Gallery
- contact.html = Contact Us

LOGO
Replace: img/logo/sfs-logo.png
Keep the same filename, or update the image path in the navbar/footer HTML.

IMAGES
Service/gallery dummy images are in img/ and have clear names such as security-services.jpg, housekeeping.jpg, party-bouncer.jpg, etc. Replace any image while keeping the filename.

PHONE NUMBERS
Main call/WhatsApp number: +91 77700 16380
Other numbers appear in contact.html. Search for the old number and replace if needed.

WHATSAPP
The floating WhatsApp button and header/footer WhatsApp links use +91 77700 16380. Search for wa.me/917770016380 to change it.

GOOGLE MAP
Open contact.html and find the iframe containing google.com/maps?q=. Replace the address in the q= part with your desired location.

FACEBOOK / INSTAGRAM
Current links are placeholders: https://www.facebook.com/ and https://www.instagram.com/
Search these URLs in index.html, about.html, service.html, project.html and contact.html and replace them with your actual profile/page links.

CONTACT FORM
The form uses Formspree. Search for: https://formspree.io/f/YOUR_FORM_ID
Create a free Formspree form and replace YOUR_FORM_ID with your actual form ID. The same form action appears in Home quote form and Contact enquiry form.

HOSTING
Netlify: drag the extracted folder into Netlify Drop, or connect a Git repository.
Cloudflare Pages: upload/connect the project and use the folder containing index.html as the site root.
GitHub Pages: upload the files to a repository and enable Pages from the repository settings.

CUSTOM DOMAIN
After deployment, use your hosting provider's Custom Domain option. Add the DNS records shown by the provider at your domain registrar.

IMPORTANT
Keep the folder structure intact. Open index.html from a local web server for best testing; some browser features behave differently when opened directly as file://.
